let fecha = new Date();

const day = fecha.toLocaleDateString("es-ES", { weekday: 'long' });


const month = fecha.toLocaleString('es-ES', { month: 'long' });


document.getElementById("fecha2").innerHTML += day + ", " + fecha.getDate() +
    " de " + month + " de " + fecha.getFullYear();

function menu() {
    if (document.getElementById("inicio").style.fontWeight === 'bold') {
        document.getElementById("menu").innerHTML += " - Inicio";
    }
}