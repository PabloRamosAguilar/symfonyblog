<?php

namespace App\Controller;

use symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class BlogController extends AbstractController
{
    public function portada()
    {
        return $this->render('portada.html.twig', []);
    }
    public function noticia($id)
    {
        return $this->render('noticia.html.twig', [ 'id' => $id]);
    }
}
