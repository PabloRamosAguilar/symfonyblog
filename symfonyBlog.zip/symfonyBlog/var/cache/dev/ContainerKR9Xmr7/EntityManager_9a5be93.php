<?php

namespace ContainerKR9Xmr7;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/src/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder2f25e = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer149b5 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties190b3 = [
        
    ];

    public function getConnection()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getConnection', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getMetadataFactory', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getExpressionBuilder', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'beginTransaction', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getCache', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getCache();
    }

    public function transactional($func)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'transactional', array('func' => $func), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'wrapInTransaction', array('func' => $func), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'commit', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->commit();
    }

    public function rollback()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'rollback', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getClassMetadata', array('className' => $className), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'createQuery', array('dql' => $dql), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'createNamedQuery', array('name' => $name), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'createQueryBuilder', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'flush', array('entity' => $entity), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'clear', array('entityName' => $entityName), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->clear($entityName);
    }

    public function close()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'close', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->close();
    }

    public function persist($entity)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'persist', array('entity' => $entity), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'remove', array('entity' => $entity), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'refresh', array('entity' => $entity), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'detach', array('entity' => $entity), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'merge', array('entity' => $entity), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getRepository', array('entityName' => $entityName), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'contains', array('entity' => $entity), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getEventManager', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getConfiguration', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'isOpen', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getUnitOfWork', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getProxyFactory', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'initializeObject', array('obj' => $obj), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'getFilters', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'isFiltersStateClean', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'hasFilters', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return $this->valueHolder2f25e->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer149b5 = $initializer;

        return $instance;
    }

    public function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config)
    {
        static $reflection;

        if (! $this->valueHolder2f25e) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder2f25e = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder2f25e->__construct($conn, $config);
    }

    public function & __get($name)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, '__get', ['name' => $name], $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        if (isset(self::$publicProperties190b3[$name])) {
            return $this->valueHolder2f25e->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2f25e;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder2f25e;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2f25e;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder2f25e;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, '__isset', array('name' => $name), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2f25e;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder2f25e;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, '__unset', array('name' => $name), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2f25e;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder2f25e;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, '__clone', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        $this->valueHolder2f25e = clone $this->valueHolder2f25e;
    }

    public function __sleep()
    {
        $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, '__sleep', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;

        return array('valueHolder2f25e');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer149b5 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer149b5;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer149b5 && ($this->initializer149b5->__invoke($valueHolder2f25e, $this, 'initializeProxy', array(), $this->initializer149b5) || 1) && $this->valueHolder2f25e = $valueHolder2f25e;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder2f25e;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder2f25e;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
